# AI-Powered Personal Finance Tracker - Final (Presentation Ready)

This repository is a **fully working demo** showcasing a full-stack application:
- Spring Boot backend with JWT authentication and PostgreSQL support
- React frontend with login/signup, JWT handling, and expense dashboard
- ML microservice (FastAPI) for categorization and prediction
- Docker Compose setup for local demo and a GitHub Actions workflow for CI/CD (pushes images to GHCR)

## Quick start (Docker - recommended)

1. Copy `docker-compose.postgres.yml` to project root.
2. Run:
```bash
docker compose -f docker-compose.postgres.yml up --build
```

3. Open http://localhost:3000
- Demo user: **demo@demo.com** / **password**

## Run locally without Docker
1. Start Postgres (or use local DB) and set env vars.
2. Start ML service:
```bash
cd ml-service
pip install -r requirements.txt
python app.py
```
3. Start backend:
```bash
cd backend
mvn clean package
mvn spring-boot:run
```
4. Start frontend:
```bash
cd frontend
npm install
npm start
```

## Notes
- For demo we included a seeded demo user in the database.
- JWT secret is configured via `JWT_SECRET` env variable; update it before production.
- This repo focuses on clarity and end-to-end functionality; you can enhance UI, add tests, and harden security for production.

## Author
**Jainam Patel**
