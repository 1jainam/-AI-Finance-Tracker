package com.finance.demo;

import com.finance.demo.model.User;
import com.finance.demo.repo.UserRepository;
import com.finance.demo.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final JwtUtil jwtUtil;
    private final UserRepository userRepo;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public AuthController(JwtUtil jwtUtil, UserRepository userRepo){
        this.jwtUtil = jwtUtil;
        this.userRepo = userRepo;
        // create demo user if not exists
        Optional<User> u = userRepo.findByEmail("demo@demo.com");
        if(u.isEmpty()){
            userRepo.save(new User("demo@demo.com", passwordEncoder.encode("password")));
        }
    }

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody Map<String,String> body){
        String email = body.get("email");
        String password = body.get("password");
        if(email==null || password==null) return ResponseEntity.badRequest().build();
        if(userRepo.findByEmail(email).isPresent()) return ResponseEntity.status(409).body(Map.of("error","User exists"));
        User u = new User(email, passwordEncoder.encode(password));
        userRepo.save(u);
        String token = jwtUtil.generateToken(email);
        return ResponseEntity.ok(Map.of("token", token));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body){
        String email = body.get("email");
        String password = body.get("password");
        if(email==null || password==null) return ResponseEntity.badRequest().build();
        Optional<User> stored = userRepo.findByEmail(email);
        if(stored.isPresent() && passwordEncoder.matches(password, stored.get().getPassword())){
            String token = jwtUtil.generateToken(email);
            return ResponseEntity.ok(Map.of("token", token));
        }
        return ResponseEntity.status(401).body(Map.of("error","Invalid credentials"));
    }
}
