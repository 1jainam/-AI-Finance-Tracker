package com.finance.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique=true)
    private String email;

    private String password;

    public User(){}
    public User(String email, String password){
        this.email = email;
        this.password = password;
    }

    public Long getId(){ return id; }
    public String getEmail(){ return email; }
    public void setEmail(String e){ this.email = e; }
    public String getPassword(){ return password; }
    public void setPassword(String p){ this.password = p; }
}
