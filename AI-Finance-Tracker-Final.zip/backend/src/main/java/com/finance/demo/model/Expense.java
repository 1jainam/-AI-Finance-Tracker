package com.finance.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Expense {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String description;
    private String category;
    private Double amount;
    private LocalDate date;

    public Expense(){}
    public Expense(String description, String category, Double amount, LocalDate date){
        this.description = description;
        this.category = category;
        this.amount = amount;
        this.date = date;
    }

    public Long getId(){ return id; }
    public String getDescription(){ return description; }
    public void setDescription(String d){ this.description = d; }
    public String getCategory(){ return category; }
    public void setCategory(String c){ this.category = c; }
    public Double getAmount(){ return amount; }
    public void setAmount(Double a){ this.amount = a; }
    public LocalDate getDate(){ return date; }
    public void setDate(LocalDate d){ this.date = d; }
}
