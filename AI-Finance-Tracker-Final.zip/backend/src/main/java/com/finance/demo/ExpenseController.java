package com.finance.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import com.finance.demo.model.Expense;
import com.finance.demo.repo.ExpenseRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ExpenseController {

    private final ExpenseRepository repo;
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${ml.service.url:http://localhost:8000}")
    private String mlUrl;

    public ExpenseController(ExpenseRepository repo){
        this.repo = repo;
        if(repo.count()==0){
            repo.save(new Expense("Pizza Hut order", "Food", 450.0, LocalDate.now().minusDays(2)));
            repo.save(new Expense("Uber ride", "Travel", 210.0, LocalDate.now().minusDays(1)));
        }
    }

    @GetMapping("/expenses")
    public List<Expense> all(){ return repo.findAll(); }

    @PostMapping("/expenses")
    public Expense create(@RequestBody Expense e){
        if(e.getDate()==null) e.setDate(LocalDate.now());
        if(e.getCategory()==null || e.getCategory().isBlank()){
            // ask ML service for category
            Map resp = restTemplate.postForObject(mlUrl + "/categorize",
                    Map.of("text", e.getDescription()==null ? "" : e.getDescription()), Map.class);
            if(resp!=null && resp.containsKey("category")){
                e.setCategory((String) resp.get("category"));
            }
        }
        return repo.save(e);
    }

    @PutMapping("/expenses/{id}")
    public ResponseEntity<Expense> update(@PathVariable Long id, @RequestBody Expense e){
        return repo.findById(id).map(x -> {
            if(e.getDescription()!=null) x.setDescription(e.getDescription());
            if(e.getCategory()!=null) x.setCategory(e.getCategory());
            if(e.getAmount()!=null) x.setAmount(e.getAmount());
            if(e.getDate()!=null) x.setDate(e.getDate());
            return ResponseEntity.ok(repo.save(x));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/expenses/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id){
        if(repo.existsById(id)){
            repo.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/predict")
    public Map<String, Object> predict(){
        Map resp = restTemplate.getForObject(mlUrl + "/predict", Map.class);
        return resp;
    }
}
