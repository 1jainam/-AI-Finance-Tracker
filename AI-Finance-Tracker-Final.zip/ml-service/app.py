from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict
import uvicorn

app = FastAPI(title="ML Service")

class TextIn(BaseModel):
    text: str

@app.post("/categorize")
def categorize(inp: TextIn) -> Dict:
    text = (inp.text or "").lower()
    if any(k in text for k in ["pizza","restaurant","food","burger"]):
        cat = "Food"
    elif any(k in text for k in ["uber","bus","train","flight","cab","taxi"]):
        cat = "Travel"
    elif any(k in text for k in ["movie","netflix","subscription","snooker"]):
        cat = "Entertainment"
    else:
        cat = "Other"
    return {"category": cat}

@app.get("/predict")
def predict():
    # dummy prediction for demo
    return {"next_month_spend_estimate": 12450.75, "currency":"INR"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
