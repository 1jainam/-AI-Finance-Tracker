import React, {useState} from 'react';
import api from '../axios';

export default function Login({onLogin}){
  const [email,setEmail]=useState('demo@demo.com');
  const [password,setPassword]=useState('password');
  const [err,setErr]=useState(null);

  const submit = async (e)=>{
    e.preventDefault();
    setErr(null);
    try{
      const res = await api.post('/auth/login',{email,password});
      localStorage.setItem('token', res.data.token);
      onLogin();
    }catch(err){
      setErr(err.response?.data?.error || 'Login failed');
    }
  };

  return (
    <div style={{marginTop:20}}>
      <h3>Login</h3>
      <form onSubmit={submit}>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
        <button type="submit">Login</button>
      </form>
      {err && <div style={{color:'red'}}>{err}</div>}
    </div>
  );
}
