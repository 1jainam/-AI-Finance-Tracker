import React, {useState} from 'react';
import api from '../axios';

export default function Signup({onSignup}){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [err,setErr]=useState(null);

  const submit = async (e)=>{
    e.preventDefault();
    setErr(null);
    try{
      const res = await api.post('/auth/signup',{email,password});
      localStorage.setItem('token', res.data.token);
      onSignup();
    }catch(err){
      setErr(err.response?.data?.error || 'Signup failed');
    }
  };

  return (
    <div style={{marginTop:20}}>
      <h3>Signup</h3>
      <form onSubmit={submit}>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
        <button type="submit">Signup</button>
      </form>
      {err && <div style={{color:'red'}}>{err}</div>}
    </div>
  );
}
