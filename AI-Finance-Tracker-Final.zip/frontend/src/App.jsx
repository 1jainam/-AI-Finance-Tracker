import React, { useEffect, useState } from "react";
import api from "./axios";
import Login from "./components/Login";
import Signup from "./components/Signup";

export default function App(){
  const [expenses, setExpenses] = useState([]);
  const [form, setForm] = useState({ description:"", amount:"", category:"" });
  const [predict, setPredict] = useState(null);
  const [auth, setAuth] = useState(!!localStorage.getItem('token'));

  const load = async () => {
    const res = await api.get('/expenses');
    setExpenses(res.data);
  };

  useEffect(()=>{ load(); },[]);

  const addExpense = async (e)=>{
    e.preventDefault();
    await api.post('/expenses', { 
      description: form.description, 
      amount: parseFloat(form.amount || 0),
      category: form.category || null 
    });
    setForm({ description:"", amount:"", category:"" });
    load();
  };

  const deleteExpense = async (id)=>{
    await api.delete(`/expenses/${id}`);
    load();
  };

  const getPredict = async ()=>{
    const res = await api.get('/predict');
    setPredict(res.data);
  };

  const logout = ()=>{
    localStorage.removeItem('token');
    setAuth(false);
  };

  return (
    <div style={{fontFamily:"sans-serif", margin:"2rem"}}>
      <h1>AI-Powered Personal Finance Tracker</h1>
      {!auth ? (
        <div style={{display:'flex', gap:40}}>
          <Login onLogin={()=>setAuth(true)} />
          <Signup onSignup={()=>setAuth(true)} />
        </div>
      ) : (
        <div>
          <button onClick={logout}>Logout</button>
          <form onSubmit={addExpense} style={{marginTop:"1rem"}}>
            <input placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
            <input placeholder="Amount" type="number" step="0.01" value={form.amount} onChange={e=>setForm({...form, amount:e.target.value})} />
            <input placeholder="Category (optional)" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} />
            <button type="submit">Add</button>
          </form>

          <h2 style={{marginTop:"1.5rem"}}>Expenses</h2>
          <table border="1" cellPadding="6">
            <thead><tr><th>ID</th><th>Description</th><th>Category</th><th>Amount</th><th>Date</th><th>Action</th></tr></thead>
            <tbody>
              {expenses.map(e=> (
                <tr key={e.id}>
                  <td>{e.id}</td>
                  <td>{e.description}</td>
                  <td>{e.category}</td>
                  <td>{e.amount}</td>
                  <td>{e.date}</td>
                  <td><button onClick={()=>deleteExpense(e.id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{marginTop:"1rem"}}>
            <button onClick={getPredict}>Get Monthly Prediction</button>
            {predict && <pre>{JSON.stringify(predict, null, 2)}</pre>}
          </div>
        </div>
      )}
    </div>
  );
}
